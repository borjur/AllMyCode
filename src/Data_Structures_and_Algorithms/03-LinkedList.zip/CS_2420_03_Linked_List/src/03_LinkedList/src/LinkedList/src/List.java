package LinkedList.src;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris Jurosevic
 */
public class List<E>
{
    SinglyLinkedList<E> list;
    
    public List()
    {
        list = new SinglyLinkedList<E>();
    }
    
    public void traverse()
    {
        for(int x = 0; x < list.getLength(); ++x)
        {
            System.out.print(list.getElementAt(x));
            if(x + 1 < list.getLength()) System.out.print(", ");
        }
        System.out.println();
    }
    
    public void add(E element)
    {
        if(element == null) throw new IllegalArgumentException();
        list.add(element);
    }
    
    public E delete(int index)
    {
        if(index < 0 || index > list.getLength() - 1) throw new IllegalArgumentException();
        
        return list.remove(index);
    }
    
    public E find(int index)
    {
        if(index < 0 || index > list.getLength() - 1) throw new IllegalArgumentException();
        
        return list.getElementAt(index);
    }
    
    public int getLength()
    {
        return list.getLength();
    }
}
