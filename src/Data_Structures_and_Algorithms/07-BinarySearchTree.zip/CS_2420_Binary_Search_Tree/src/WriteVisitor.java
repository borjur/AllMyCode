/*
 * Boris Jurosevic
 * CS 2420
 * Binary Search Tree
 */
import gray.adts.binarysearchtree.BSTNode;
import gray.adts.binarysearchtree.Visitor;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class WriteVisitor<E extends Comparable<? super E> & Serializable>
		implements Visitor<E> {

	private final ObjectOutputStream stream;

	public WriteVisitor(ObjectOutputStream stream) {
		this.stream = stream;
	}

	@Override
	public void visit(BSTNode<E> node) {
		try {
			this.stream.writeObject(node.getElement());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}