package List_Using_Arrays.src;


import java.util.ArrayList;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris Jurosevic
 */
public class ListTest 
{
    public static void main(String[] args)
    {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(4);
        arrayList.add(6);
        arrayList.add(2);
        arrayList.add(9);
        arrayList.add(3);
        
        List<Integer> list = new List<Integer>(Integer[].class, arrayList);
        list.traverse();
        
        list.replace(3, 7);
        list.traverse();
        
        list.insert(3, 1);
        list.traverse();
        
        list.delete(3);
        list.traverse();
        
        List<Integer> list1 = new List<Integer>(Integer[].class);
        list1.traverse();
        
        list1.insert(0, 7);
        list1.traverse();
        
        list1.insert(0, 1);
        list1.traverse();
        
        list1.delete(1);
        list1.traverse();
    }
}
