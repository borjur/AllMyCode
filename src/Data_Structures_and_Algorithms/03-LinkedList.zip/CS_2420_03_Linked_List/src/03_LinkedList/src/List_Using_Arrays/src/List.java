package List_Using_Arrays.src;


import java.lang.reflect.Array;
import java.util.Collection;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris Jurosevic
 */
public class List<T>
{
    private static final int DEFAULT_SIZE = 100;
    private T[] list;
    private int size = 0;
    
    public List(Class<T[]> c)
    {
        list = c.cast(Array.newInstance(c.getComponentType(), DEFAULT_SIZE));
        size = 0;
    }
    
    public List(Class<T[]> c, Collection<? extends T> collection)
    {
        if(c == null) throw new IllegalArgumentException();
        
        int capacity = collection.size() > DEFAULT_SIZE 
                ? (collection.size()*110)/100 : DEFAULT_SIZE;
        
        list = c.cast(Array.newInstance(c.getComponentType(), capacity));
        collection.toArray(list);
        size = collection.size();
    }
    
    public void traverse()
    {
        System.out.print("[");
        for(int x = 0; x < size; ++x)
        {
            System.out.print(list[x]);
            if(x < size-1) System.out.print(", ");
        }
        System.out.println("]");
    }
    
    public void resize()
    {
        T[] temp = (T[])new Object[list.length * 2];
        System.arraycopy(list, 0, temp, 0, list.length);
        list = temp;
    }
    
    public void replace(int index, T element)
    {
        if(index < 0 || index > size || element == null) throw new IllegalArgumentException();
        
        list[index] = element;
    }
    
    public void insert(int index, T element)
    {
        if(index < 0 || index > size || element == null) throw new IllegalArgumentException();
        if(size == list.length) resize();
        for(int x = size-1; x >= index; --x)
        {
            list[x + 1] = list[x];
        }
        replace(index, element);
        ++size;
    }
    
    public void delete(int index)
    {
        if(index < 0 || index > size - 1) throw new IllegalArgumentException();
        for(int x = index; x < size; ++x)
        {
            list[x] = list[x+1];
        }
        --size;
    }
}
