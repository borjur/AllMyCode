package LinkedList.src;


import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris Jurosevic
 */
public class TestList 
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        List<Book> list = new List<Book>();
        list.add(new Book("My Swell Book", 1910));
        list.add(new Book("My Cool Book", 1950));
        list.add(new Book("My Groovy Book", 1967));
        list.add(new Book("My Awesome Book", 1980));
        list.add(new Book("My Wicked Book", 1990));
        
        int menuChoice = 4;
        do
        {
            try
            {
                displayMenu();
                menuChoice = scanner.nextInt();
                switch(menuChoice)
                {
                    case 1:
                        System.out.println("Enter a title: ");
                        String title = scanner.next();
                        System.out.println("Enter a year: ");
                        int year = scanner.nextInt();
                        list.add(new Book(title, year));
                        break;
                    case 2:
                        System.out.println("Which item would you like to delete? You may enter an integer value from 0 to " + (list.getLength() - 1));
                        int deleteIndex = scanner.nextInt();
                        list.delete(deleteIndex);
                        break;
                    case 3:
                        System.out.println("Which item would you like to find? You may enter an integer value from 0 to " + (list.getLength() - 1));
                        int findIndex = scanner.nextInt();
                        System.out.println("The item at " + findIndex + "is " + list.find(findIndex));
                        break;
                    case 4:
                        list.traverse();
                        break;
                    case 5:
                        break;
                    default:
                        System.out.println("Invalid selection. Try again.");
                }
            }
            catch(InputMismatchException e)
            {
                System.out.println("Invalid selection. Try again.");
            }
        }
        while(menuChoice != 5);
    }
    
    private static void displayMenu()
    {
        System.out.println("Choose a menu option: ");
        System.out.println("1. Add an item.");
        System.out.println("2. Delete an item.");
        System.out.println("3. Find an item.");
        System.out.println("4. Display the list.");
        System.out.println("5. Exit");
    }
}
