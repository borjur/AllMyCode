/*
 * Boris Jurosevic
 * CS 2420
 * Binary Search Tree
 */
package gray.adts.binarysearchtree;

import java.util.ArrayList;

public class ToTest {
	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		Object o = new Object();
		BSTNode<Integer> n1 = new BSTNode<Integer>(20);
		// BSTNode<Object> n2 = new BSTNode<Object>( o );
		AVLNode<Integer> n3 = new AVLNode<Integer>(20);
		// AVLNode<Object> n4 = new AVLNode<Object>( o );

	}
}