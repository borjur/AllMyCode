/*
 * Boris Jurosevic
 * CS 2420
 * Binary Search Tree
 */
import java.io.Serializable;

public class Student implements Comparable<Student>, Serializable {

	private static final long serialVersionUID = 1L;
	public String firstName;
	public double gpa;
	public String lastName;
	public String major;
	public int studentNumber;

	public Student(String firstName, String lastName, String major, double gpa,
			int studentNumber) {
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setMajor(major);
		this.setGpa(gpa);
		this.setStudentNumber(studentNumber);
	}

	@Override
	public int compareTo(Student o) {
		if (this.getLastName().compareTo(o.getLastName()) == 0) {
			return this.getFirstName().compareTo(o.getFirstName());
		} else {
			return this.getLastName().compareTo(o.getLastName());
		}
	}

	public String getFirstName() {
		return this.firstName;
	}

	public double getGpa() {
		return this.gpa;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String getMajor() {
		return this.major;
	}

	public int getStudentNumber() {
		return this.studentNumber;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public void setStudentNumber(int studentNumber) {
		this.studentNumber = studentNumber;
	}

	@Override
	public String toString() {
		return this.getLastName() + ", " + this.getFirstName() + "; number:"
				+ this.getStudentNumber() + "; gpa:" + this.getGpa()
				+ "; major:" + this.getMajor();

	}
}
