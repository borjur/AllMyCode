package LinkedList.src;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris Jurosevic
 */
public class Book 
{
    private String title;
    private int copyrightYear;
    
    public Book(String title, int year)
    {
        this.title = title;
        this.copyrightYear = year;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public int getCopyrightYear()
    {
        return copyrightYear;
    }

    public void setCopyrightYear(int copyrightYear)
    {
        this.copyrightYear = copyrightYear;
    }

    @Override
    public String toString()
    {
        return "Book{" + "title=" + title + ", copyrightYear=" + copyrightYear + '}';
    }
}
