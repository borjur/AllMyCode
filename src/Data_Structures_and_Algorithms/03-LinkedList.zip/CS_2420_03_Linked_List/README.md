slicc
=====

school projects
