/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BasicLinkedCollection.src.basiclinkedcollection;

import java.util.ArrayList;

/**
 *
 * @author wade
 */
public class BasicLinkedCollectionTest 
{
    public static void main(String[] args)
    {
        BasicLinkedCollection<Integer> list = new BasicLinkedCollection<Integer>();
        list.add(4);
        list.add(3);
        list.add(5);
        list.add(2);
        list.add(1);
        System.out.println(list.toString());
        list.remove(5);
        System.out.println(list.toString());
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(90);
        arrayList.add(89);
        arrayList.add(88);
        arrayList.add(87);
        arrayList.add(86);
        list.addAll(arrayList);
        System.out.println(list.toString());
        arrayList.remove(new Integer(87));
        arrayList.remove(new Integer(86));
        arrayList.remove(new Integer(3));
        arrayList.remove(new Integer(2));
        arrayList.add(1);
        arrayList.add(4);
        list.removeAll(arrayList);
        System.out.println(list.toString());
        
        BasicLinkedCollection<Integer> list2 = new BasicLinkedCollection<Integer>(arrayList);
        System.out.println(list2.toString());
    }
}
