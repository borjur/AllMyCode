/**
 * Boris Jurosevic
 * CS 2420
 * Assignment 6 Stacks
 * Date : 03/07/2013
 */

package src.main;

import java.util.ArrayList;
import java.util.ListIterator;

import src.gray.ListStack;

//public class main
public class MainStacks
{

    ///main method
	public static void main( String[ ] args )
	{
		//array of strings 
		ArrayList< String > stringList = new ArrayList<String>( );
		stringList.add( "First Dog" );
		stringList.add( "Second Cat" );
		stringList.add( "Third Donkey" );
		
        //prints out list of strings in order and in reverse order
		System.out.println( "Display a list of Strings in-order" );
		MainStacks.printList( stringList );
		System.out.println( "Display a list of Strings in reverse-order" );
		MainStacks.reverse( stringList );
		MainStacks.printList( stringList );
        
		
		//aray of integers
		ArrayList< Integer > intList = new ArrayList<Integer>( );
		intList.add( 1 );
		intList.add( 2 );
		intList.add( 3 );
        //prints out list of integers in order and in reverse order
		System.out.println( "Display a list of Integers in-order" );
		MainStacks.printList( intList );
		System.out.println( "Display a list of Integers in reverse-order" );
		MainStacks.reverse( intList );
		MainStacks.printList( intList );

	}

	public static < E > void printList( ArrayList< E > list )
	{
		for ( E item : list )
		{
			System.out.println( item );
		}
	}

	public static < E > void reverse( ArrayList< E > list )
	{
		ListStack< E > stack = new ListStack< E >( );
		ListIterator< E > iter = list.listIterator( );
		while ( iter.hasNext( ) )
		{
			stack.push( iter.next( ) );
		}
		list.clear( );
		while ( !stack.isEmpty( ) )
		{
			list.add( stack.pop( ) );
		}
	}

}