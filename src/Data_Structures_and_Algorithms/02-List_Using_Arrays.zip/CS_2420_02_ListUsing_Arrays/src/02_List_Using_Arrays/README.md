<<<<<<< HEAD
slicc
=====

school projects
=======
projects
========
>>>>>>> branch 'master' of https://github.com/borjur/projects.git
