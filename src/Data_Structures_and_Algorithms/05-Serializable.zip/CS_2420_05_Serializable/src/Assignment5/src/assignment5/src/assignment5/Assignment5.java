/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Assignment5.src.assignment5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ListIterator;

/**
 *
 * @author Boris Jurosevic
 */
public class Assignment5 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        LinkedList<AccountRecordSerializable> list = new LinkedList<AccountRecordSerializable>();
        list.add(new AccountRecordSerializable(1, "Ben", "Smith", 4.50));
        list.add(new AccountRecordSerializable(2, "John", "Anderson", 95650.75));
        list.add(new AccountRecordSerializable(3, "Kevin", "Tolman", 4534.65));
        list.add(new AccountRecordSerializable(4, "Jeremy", "Hunt", 0.0));
        list.add(new AccountRecordSerializable(5, "Eric", "Johnson", 4354543.56));
        
        ListIterator itr = list.listIterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }
        System.out.println();
        
        itr = list.listIterator(list.size());
        while(itr.hasPrevious())
        {
            System.out.println(itr.previous());
        }
        System.out.println();
        
        itr = list.listIterator(1);
        int counter = 0;
        while(counter++ < 3 && itr.hasNext())
        {
            System.out.println(itr.next());
        }
        System.out.println();
        
        try
        {
            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("linkedlist.out"));
            output.writeObject(list);
            output.close();
            
            LinkedList<AccountRecordSerializable> list2;
            ObjectInputStream input = new ObjectInputStream(new FileInputStream("linkedlist.out"));
            list2 = (LinkedList<AccountRecordSerializable>)input.readObject();
            
            itr = list2.listIterator();
            while(itr.hasNext())
            {
                System.out.println(itr.next());
            }
            System.out.println();
        }
        catch(FileNotFoundException fnfe)
        {
            fnfe.printStackTrace();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
        catch(ClassNotFoundException cnfe)
        {
            cnfe.printStackTrace();
        }
    }

}
