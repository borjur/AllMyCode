/**
 * 
 * @author Boris Jurosevic 
 * CS 2420 
 * Assignment Recursion
 */
public class SLTest<E>
{

    //main method      
    public static void main(String args[])
    {
        int i = 0;
        SinglyLinkedList<String> list = new SinglyLinkedList<String>();
        //list of strings
        list.add("first", i);
        list.add("second", i);
        list.add("third", i);
        list.add("fourth", i);
        System.out.println("Printing the list in reverse order and in order");
        System.out.println(list);
        //recurvie method
        list.printReverse();
        
    }
}
