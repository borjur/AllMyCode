/*
 * Boris Jurosevic
 * CS 2420
 * Binary Search Tree
 */
import gray.adts.binarysearchtree.LinkedBST;
import gray.adts.binarysearchtree.Visitor;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class StudentBST {

	private static LinkedBST<Student> students;

	public StudentBST() {
		StudentBST.students = new LinkedBST<Student>();
	}

	public static StudentBST loadStudentCollection() {
		ObjectInputStream input = null;
		StudentBST students = new StudentBST();
		int count = 0;
		try {
			input = new ObjectInputStream(new FileInputStream("students.ser"));
			Student student = null;
			while (true) {
				student = (Student) input.readObject();
				StudentBST.students.add(student);
				count++;
			}
		} catch (EOFException e) {
			String plural = (count > 1) ? "s" : "";
			System.out.println("Loaded " + count + " student" + plural);
		} catch (FileNotFoundException e) {
			System.out
					.println("Students file doesn't exist, we'll save one when you exit");
		} catch (IOException e) {
			System.out.println("--- ioexception while loading");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (input != null) {
					input.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return students;
	}

	public void add(Student student) {
		StudentBST.students.add(student);
	}

	private Student findStudentByNumber(int studentNumber) {
		for (Student student : StudentBST.students) {
			if (student.getStudentNumber() == studentNumber) {
				return student;
			}
		}
		return null;
	}

	public void printAllStudents() {
		for (Student student : StudentBST.students) {
			System.out.println(student);
		}
	}

	public void printStudentsByGPA(double gpa) {
		this.printStudentsByGPA(gpa, false);
	}

	public void printStudentsByGPA(double gpa, boolean lessThan) {
		for (Student student : StudentBST.students) {
			if (lessThan && (student.getGpa() < gpa)) {
				System.out.println(student);
			} else if (!lessThan && (student.getGpa() > gpa)) {
				System.out.println(student);
			}
		}
	}

	public void printStudentsByMajor(String major) {
		for (Student student : StudentBST.students) {
			if (student.getMajor().equals(major)) {
				System.out.println(student);
			}
		}
	}

	public void remove(int studentNumber) {
		Student student = this.findStudentByNumber(studentNumber);
		StudentBST.students.remove(student);
	}

	public void saveStudentCollection() {
		ObjectOutputStream output = null;
		try {
			output = new ObjectOutputStream(
					new FileOutputStream("students.ser"));
			Visitor<Student> visitor = new WriteVisitor<Student>(output);
			StudentBST.students.postOrderTraversal(visitor);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (output != null) {
					output.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}