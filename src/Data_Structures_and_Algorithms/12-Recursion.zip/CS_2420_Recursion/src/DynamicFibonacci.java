/**
 * 
 * @author Boris Jurosevic 
 * CS 2420 
 * Assignment Recursion
 */
public class DynamicFibonacci {
	private long[] fibs;
	private int lastComputedFib;
	private int capacity;

	public static void main(String[] args) {
		DynamicFibonacci fib = new DynamicFibonacci(100);
		System.out.println(fib.getNextFib());
		System.out.println(fib.getNextFib());
		System.out.println(fib.getFib(10));
		System.out.println(fib.getFib(7));
		System.out.println(fib.getFib(100));
		System.out.println(fib.getFib(90));
	}

	public DynamicFibonacci(int size) {
		capacity = size;
		fibs = new long[capacity + 1];
		fibs[0] = 0;
		fibs[1] = 1;
		fibs[2] = 1;
		lastComputedFib = 2;
	}

	public long getNextFib() {
		if (lastComputedFib > capacity)
			return -1;
		lastComputedFib++;
		fibs[lastComputedFib] = fibs[lastComputedFib - 1]
				+ fibs[lastComputedFib - 2];
		return fibs[lastComputedFib];
	}

	public long getFib(int n) {
		int i;
		if (n > capacity)
			return -1;
		lastComputedFib++;
		if (lastComputedFib > n)
			return fibs[n];
		for (; lastComputedFib <= n; lastComputedFib++) {
			fibs[lastComputedFib] = fibs[lastComputedFib - 1]
					+ fibs[lastComputedFib - 2];
		}
		lastComputedFib--;
		return fibs[lastComputedFib];
	}
}
