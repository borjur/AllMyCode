/**
 * 
 * @author Boris Jurosevic 
 * CS 2420 
 * Assignment Recursion
 */
public class BinarySearch {
	public static void main(String[] args) {
		int[] collection = { 0, 1, 2, 3, 4, 5, 6, 7, 9, 10 };
		System.out
				.println(BinarySearch(collection, 0, collection.length - 1, 9));
	}

	public static int BinarySearch(int[] collection, int first, int last,
			int target) {
		int mid = (first + last) / 2;
		if (first > last)
			return -1;
		if (collection[mid] == target)
			return mid;
		if (collection[mid] < target)
			return BinarySearch(collection, mid + 1, last, target);
		else
			return BinarySearch(collection, first, mid - 1, target);
	}
}
